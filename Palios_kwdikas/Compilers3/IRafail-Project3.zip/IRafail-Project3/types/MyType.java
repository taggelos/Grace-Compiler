package types;

public class MyType {
	public String name;

	public MyType(String name) {
		this.name = name;
	}
}